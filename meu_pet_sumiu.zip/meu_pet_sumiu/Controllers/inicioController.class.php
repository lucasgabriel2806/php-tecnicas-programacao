<?php
	class inicioController
	{
		public function inicio()
		{
			require_once "Views/menu.php";
		}
	}
?>