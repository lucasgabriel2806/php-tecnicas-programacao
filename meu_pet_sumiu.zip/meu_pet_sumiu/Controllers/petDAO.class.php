<?php
	class petDAO extends Conexao
	{
		public function __construct()
		{
			parent:: __construct();
		}
		
		public function buscar_pets()
		{
		}
		
		public function inserir()
		{
		}
	}//fim da classe
?>