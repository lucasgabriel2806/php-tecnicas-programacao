<?php
    //require_once "verificar_permissao.php";
    class categoriaController
    {
        public function listar()
        {
            $categoriaDAO = new categoriaDAO();				
			$retorno = $categoriaDAO->buscar_todas();
            require_once "views/listar_categorias.php";
        }

        public function buscar_categorias_ativas()
        {
            //buscar categorias BD
						
				$categoria = new Categoria(status:"Ativo");
						
				$categoriaDAO = new categoriaDAO();
						
				$retorno = $categoriaDAO->buscar_categorias_ativas($categoria);
                return $retorno;
        }

        public function inserir()
        {
			$erro = "";
			if($_POST)
			{
				if(empty($_POST["descritivo"]))
				{
					$erro = "Preencha o descritivo da categoria";
				}
				else
				{
					$categoria = new Categoria(0 , $_POST["descritivo"], "Ativo");
					//inserir
					$categoriaDAO = new categoriaDAO();
					$categoriaDAO->inserir($categoria);
					header("location:/loja/listar_categorias");
					die();
				}
			}//fim if $post
			require_once "views/form_categoria.php";
        }

        public function alterar()
        {
           	if($_POST)
			{
				if(empty($_POST["descritivo"]))
				{
					$erro = "Preencha o descritivo da categoria";
					header("location:/loja/editar?id={$_POST['idcategoria']}&erro=$erro");
					die();
				}
				else
				{
					$categoria = new Categoria($_POST["idcategoria"] , $_POST["descritivo"]);
					//alterar
					$categoriaDAO = new categoriaDAO();
					$categoriaDAO->alterar($categoria);
					header("location:/loja/listar_categorias");
					die();
				}
			} //fim if $post
			
        }
		public function editar($id)
		{
			
				
				$categoria = new Categoria($id);
				$categoriaDAO = new categoriaDAO();
				$retorno = $categoriaDAO->buscar_uma_categoria($categoria);
			
				require_once "views/editar.php";
		}
        public function excluir($id)
        {
            
				$categoria = new Categoria($id);
				
				$categoriaDAO = new categoriaDAO();
				$msg = $categoriaDAO->excluir($categoria);
				header("location:/loja/listar_categorias?msg=$msg");
				die();
			
        }
		public function mudar_status($id)
		{
			
		}
        
    }//fim da classe
?>