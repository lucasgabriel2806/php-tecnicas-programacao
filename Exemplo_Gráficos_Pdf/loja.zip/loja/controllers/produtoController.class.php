<?php
    class produtoController
    {
        public function buscar_produtos()
        {
            $produtoDAO = new produtoDAO();
            $produtos = $produtoDAO->buscar_todos();
            return $produtos;
        }

        public function busca_produtos_categoria($id)
        {
            $produtoDAO = new produtoDAO();
					
			//buscar apenas os produtos da categoria escolhida
			$categoria = new Categoria($id);
			$produto = new Produto(categoria:$categoria);
			$produtos = $produtoDAO->buscar_produtos_por_categoria($produto); 
			$categoriaController = new categoriaController();
			$retorno = $categoriaController->buscar_categorias_ativas();
			require_once "views/menu.php";
			
		     
        }//fim metodo vusca_produtos_categorias

        public function listar()
        {
            $produtoDAO =  new produtoDAO();
			$retorno = $produtoDAO->buscar_todos();
            require_once "views/listar_produtos.php";
        }

        public function inserir()
        {
		   $msg = array("","","","","","");
			if($_POST)
			{
				$erro = false;
				if(empty($_POST["nome"]))
				{
					$msg[0] = "Preencha o nome do produto";
					$erro = true;
				}
				
				if(empty($_POST["descricao"]))
				{
					$msg[1] = "Preencha a descrição do produto";
					$erro = true;
				}
				
				if(empty($_POST["preco"]))
				{
					$msg[2] = "Preencha o preço do produto";
					$erro = true;
				}
				
				if(empty($_POST["estoque"]))
				{
					$msg[3] = "Preencha o estoque do produto";
					$erro = true;
				}
				
				if($_POST["categoria"] == "0")
				{
					$msg[4] = "Escolha uma categoria para o produto";
					$erro = true;
				}
				if($_FILES["imagem"]["name"] == "")
				{
					$msg[5] = "Escolha uma imagem para o produto";
					$erro = true;
				}
				else
				{
					if($_FILES["imagem"]["type"] != "image/png" &&    $_FILES["imagem"]["type"] != "image/jpg" && 
					$_FILES["imagem"]["type"] != "image/jpeg")
					{
						$msg[5] = "Tipo de imagem invalido";
						$erro = true;
					}
				}
				
				if(!$erro)
				{
					//inserir no BD
					$categoria = new Categoria($_POST["categoria"]);
					
					$produto = new Produto(0, $_POST["nome"], $_POST["descricao"], $_POST["preco"], $_FILES["imagem"]["name"], $_POST["estoque"], $categoria);
					
					$produtoDAO = new produtoDAO();
					
					$produtoDAO->inserir($produto);
					
					header("location:/loja/listar_produtos");
					die();
					
				}
				
			}//fim if post
			//buscar categorias BD
					
			$categoria = new Categoria(status:"Ativo");
					
			$categoriaDAO = new categoriaDAO();
					
			$ret = $categoriaDAO->buscar_categorias_ativas($categoria);
			require_once "Views/form_produto.php"; 
        }
		
        

        public function excluir($id)
        {
            
				$produto = new Produto($id);
				$produtoDAO = new produtoDAO();
				$msg = $produtoDAO->excluir($produto);
				header("location:/loja/listar_produtos?msg=$msg");
				die();
			
        }
		public function estoque()
		{
			$produtoDAO = new produtoDAO();
            $produtos = $produtoDAO->buscar_todos();
			require_once "views/produtopdf.php";
		}
        
    }//fim da classe
?>