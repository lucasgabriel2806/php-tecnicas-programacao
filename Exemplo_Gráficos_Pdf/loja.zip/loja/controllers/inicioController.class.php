<?php
    class inicioController
    {
        public function inicio()
        {
            //buscar os dados no banco
            
            $categoriaController = new categoriaController();
            $retorno = $categoriaController->buscar_categorias_ativas();
            $produtoController = new produtoController();
            $produtos = $produtoController->buscar_produtos();
           
            require_once "views/menu.php";
        }
    }
?>