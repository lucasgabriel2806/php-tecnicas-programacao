<?php
	date_default_timezone_set("America/Sao_Paulo");
	
	if(!isset($_SESSION))
	{
		session_start();
	}
	class compraController
	{
		public function mostrar_carrinho()
		{
			require_once "views/carrinho.php";			
		}
		public function inserir_carrinho($id)
		{
			
			$linha = -1;
			$achou = false;
			if(isset($_SESSION["carrinho"]))
			{
				foreach($_SESSION["carrinho"] as $linha=>$dado)
				{
					if($dado["id"] == $id)
					{
						$achou = true;
					}
				}//fim foreach
			}//fim if isset
			//verificar se o produto não está no carrinho
			if(!$achou)
			{
				//inserir no carrinho
				
				//buscar os dados do produto BD
				$produto = new Produto($id);
				
				$produtoDAO = new ProdutoDAO();
				$retorno = $produtoDAO->buscar_um($produto);
				
				//guardar na sessão
				$_SESSION["carrinho"][$linha + 1]["id"] = $retorno[0]->idproduto;
				
				$_SESSION["carrinho"][$linha + 1]["nome"] = $retorno[0]->nome;
				
				$_SESSION["carrinho"][$linha + 1]["preco"] = $retorno[0]->preco;
				
				$_SESSION["carrinho"][$linha + 1]["quantidade"] = 1;
			}//fim if achou
			header("location:/loja/mostrar_carrinho");
			die();
			
		}//fim do método
		public function alterar_carrinho()
		{
			if(isset($_GET["linha"]))
			{
				$_SESSION["carrinho"][$_GET["linha"]]["quantidade"] = $_GET["quant"];
			}
			
		}
		public function excluir_carrinho()
		{
			if(isset($_GET["linha"]))
			{
				unset($_SESSION["carrinho"][$_GET["linha"]]);
				header("location:/loja/mostrar_carrinho");
				die();
			}
		}
		public function finalizar_compra()
		{
			//verificar se está logado
			if(isset($_SESSION["nome"]))
			{
				//gravar a compra no BD
				$usuario = new Usuario($_SESSION["idusuario"]);
				$compra = new Compra(data_compra:date("Y-m-d"), usuario:$usuario);
				
				foreach($_SESSION["carrinho"] as $item)
				{
					$produto = new Produto($item["id"]);
					$compra->setItens(0, $item["quantidade"], $item["preco"], $produto);
				}
				$compraDAO = new compraDAO();
				$retorno = $compraDAO->inserir_compra($compra);
			
				//apagar carrinho da sessão
				unset($_SESSION["carrinho"]);
				
				//voltar para home
				header("location:/loja/?msg=$retorno");
				die();
				
			}
			else
			{
				header("location:/loja/login");
				die();
			}
		}
		public function grafico($tipo)
		{
			if($tipo == "B")
			{
				require_once "views/gerar_grafico_barras.php";
			}
			else if($tipo == "P")
			{
				require_once "views/gerar_grafico_Pizza.php";
			}
			
		}
		public function buscar_dados_grafico()
		{
			$compraDAO = new compraDAO();
			$retorno = $compraDAO->dados_grafico();
			$retorno = json_encode($retorno);
			echo $retorno;
			//var_dump($retorno);
		}
	}//fim da classe
?>