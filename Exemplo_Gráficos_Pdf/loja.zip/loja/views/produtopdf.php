<?php
	date_default_timezone_set("America/Sao_Paulo");
	require_once "vendor/autoload.php";
	$mpdf = new \Mpdf\mpdf();
	
	$header = "<h1>Estoque - <span>" . date("d/m/Y") . "</span></h1>";
	
	$body = "<table>
			 <tr>
			 <th>Produto</th>
			 <th>Preço</th>
			 <th>Estoque</th>
			 <th>Subtotal</th>
			 </tr>";
			 $total = 0;
	foreach($produtos as $dado)
	{
		$subtotal = $dado->preco * $dado->estoque;
		$total +=$subtotal;
		$subtotal = number_format($subtotal, 2, ",",".");
		$preco = number_format($dado->preco,2,",",".");
		$body = $body . "<tr><td>{$dado->nome}</td>
	<td>$preco</td><td>{$dado->estoque}</td><td>$subtotal</td></tr>";
	}
	$total = number_format($total, 2, ",", ".");
	$body = $body . "<tr><td colspan='3'>Total</td><td>$total</td></tr></table>";
	
	$html = $header . $body;
	
	
	
	$estilo = file_get_contents("style/estilo.css");
	$mpdf->WriteHTML($estilo, 1);
	
	$mpdf->WriteHTML($html);
	$mpdf->Output();
?>