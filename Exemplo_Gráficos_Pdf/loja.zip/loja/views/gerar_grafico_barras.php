<?php
	require_once "header.php";
?>
<div class="content">
<div class="container">
	<br><br><div id="grafico"></div>
</div>
</div>
<script	src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
	var url = "/loja/buscar_dados";
	fetch(url)
	.then((response)=>{
		return response.json();
	})
	.then((data)=>{
		//console.log(data);
		gerar_grafico(data);
	})
	.catch((error)=>{
		console.log(error);
	});
	
	function gerar_grafico(dados)
	{
		var valorBarras = [];
		var legendas = [];
		
		for(let x=0; x < dados.length;x++)
		{
			valorBarras[x] = dados[x].valor;
			legendas[x] = dados[x].nome;
		}
		
		var options = {
          series: [{
            data: valorBarras}],
          chart: {
          type: 'bar',
          height: 350,
		  width:700
		  },
		  
        xaxis: {
			categories:legendas,
            labels: {
            style:{
				fontSize:'12px'
			}
          }
        },
		
        title: {
            text: 'Produtos mais vendidos',
			align: 'center',
			style: {
				color:'#444'
			}
        },
        
       };

        var chart = new ApexCharts(document.querySelector("#grafico"), options);
        chart.render();
	}
</script>