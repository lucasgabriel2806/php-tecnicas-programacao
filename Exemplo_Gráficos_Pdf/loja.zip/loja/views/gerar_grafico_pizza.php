<?php
	require_once "header.php";
?>
<div class="content">
<div class="container">
	<br><br><div id="grafico"></div>
</div>
</div>
<script	src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
	var url = "/loja/buscar_dados";
	fetch(url)
	.then((response)=>{
		return response.json();
	})
	.then((data)=>{
		//console.log(data);
		gerar_grafico(data);
	})
	.catch((error)=>{
		console.log(error);
	});
	
	function gerar_grafico(dados)
	{
		var valor = [];
		var legendas = [];
		
		for(let x=0; x < dados.length;x++)
		{
			valor[x] = parseInt(dados[x].valor);
			legendas[x] = dados[x].nome;
		}
		
		var options = {
          series: valor,
          chart: {
          width: 600,
          type: 'pie',
        },
        labels: legendas,
        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };
        var chart = new ApexCharts(document.querySelector("#grafico"), options);
        chart.render();
	}
</script>