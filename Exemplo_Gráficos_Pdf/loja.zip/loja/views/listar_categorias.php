<?php
	require_once "header.php";
	
	if(isset($_GET["msg"]))
	{
		echo "<h3>{$_GET["msg"]}</h3>";
	}
?>
	<div class="content">
	<div class="container">
		<br><br><h1>Lista de Categorias</h1><br>
		<br><a href="/loja/inserir"   class="btn btn-success">Nova Categoria</a>
		<br><br>
		<table class="table table-striped">
			<tr>
				<th>Código</th>
				<th>Categoria</th>
				<th>Status</th>
				<th>Ações</th>
			</tr>
			<?php	
				foreach($retorno as $dado)
				{
					echo "<tr>
							<td>{$dado->idcategoria}</td>
							<td>{$dado->descritivo}</td>
							<td>{$dado->status}</td>
							<td>
								<a href='/loja/editar/{$dado->idcategoria}' class='btn btn-warning'>Alterar</a>
								
								&nbsp;&nbsp;
								
								<a href='/loja/excluir/{$dado->idcategoria}' class='btn btn-danger'>Excluir</a>
								
								&nbsp;&nbsp;";
								if($dado->status == "Ativo")
								{
									echo "<a href='/loja/status/{$dado->idcategoria}/'Inativo' class='btn btn-warning'>Inativar</a>";
								}
								else
								{
									echo "<a href='/loja/status/{$dado->idcategoria}/'Ativo' class='btn btn-warning'>Ativar</a>";
								}
						echo "</td>
						  </tr>";
				}//fim do foreach
			?>
		</table>
		
	</div>
</div>
<?php
	require_once "footer.html";
?>