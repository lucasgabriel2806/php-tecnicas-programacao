<?php
	class Compra
	{
		public function __construct(private int $id_compra = 0, private string $data_compra = "", private $usuario = null){}
		
		public function getId_compra()
		{
			return $this->id_compra;
		}
		public function getData_compra()
		{
			return $this->data_compra;
		}
		public function getUsuario()
		{
			return $this->usuario;
		}
		public function getItens()
		{
			return $this->itens;
		}
		public function setItens($id_item, $quantidade, $preco_unitario, $produto)
		{
			$this->itens[] = new Itens($id_item, $quantidade, $preco_unitario, $produto);
		}
	}
?>