<?php
	class compraDAO extends Conexao
	{
		public function __construct()
		{
			parent:: __construct();
		}
		
		public function inserir_compra($compra)
		{
			$this->db->beginTransaction();
			$sql = "INSERT INTO compras (data_compra, id_usuario) VALUES(?,?)";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->bindValue(1, $compra->getData_compra());
				$stm->bindValue(2, $compra->getUsuario()->getIdusuario());
				$stm->execute();
				$idcompra = $this->db->lastInsertId();
			}
			catch(PDOException $e)
			{
				$this->db = null;
				return "Problema ao inserir a compra";
			}
			
			$sql = "INSERT INTO itens (quantidade, preco_unitario, id_compra, id_produto) VALUES(?,?,?,?)";
			
			foreach($compra->getItens() as $item)
			{
				try
				{
					$stm = $this->db->prepare($sql);
					$stm->bindValue(1,$item->getQuantidade());
					$stm->bindValue(2,$item->getPreco_unitario());
					$stm->bindValue(3, $idcompra);
					$stm->bindValue(4, $item->getProduto()->getIdproduto());
					$stm->execute();
				}
				catch(PDOException $e)
				{
					$this->db->rollback();
					$this->db = null;
					return $e->getMessage();
				}
			}//fim do foreach
			$this->db->commit();
			$this->db = null;
			return "Compra inserida com sucesso";
		}
		public function dados_grafico()
		{
			$sql = "SELECT nome, SUM(quantidade) as valor FROM produtos, itens WHERE produtos.idproduto = itens.id_produto GROUP BY itens.id_produto desc limit 3";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->execute();
				$this->db = null;
				return $stm->fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e)
			{
				$this->db = null;
				return "Problema ao buscar os dados para o gráfico";
			}
		}
	}//fim da classe
?>